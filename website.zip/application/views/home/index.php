<body>


	<!--Revolution Slider-->
	<div class="clv_rev_slider">
		<div id="rev_slider_1164_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="exploration-header" data-source="gallery" style="background-color:transparent;padding:0px;">
			<!-- START REVOLUTION SLIDER 5.4.1 fullscreen mode -->
			<div id="rev_slider_1164_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
				<ul>
					<!-- SLIDE  -->
					<li data-index="rs-3204" data-transition="slideoververtical" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="../../assets/images/news1-1-100x50.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="2000" data-fsslotamount="7" data-saveperformance="off" data-title="" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
						<!-- MAIN IMAGE -->
						<img src="images/image_2.webp" alt="image" data-lazyload="" data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
						<!-- LAYERS -->

						<!-- LAYER NR. 1 -->
						<div class="tp-caption  " id="slide-3204-layer-1" data-x="['left','left','left','left']" data-hoffset="['364','114','76','26']" data-y="['top','top','top','top']" data-voffset="['262','252','195','185']" data-fontsize="['20','20','20','20']" data-lineheight="['22','22','22','22']" data-width="['700','700','700','700']" data-height="none" data-whitespace="normal" data-type="text" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 5; white-space: nowrap; font-size: 20px; font-weight: 700; color: #1fa12e; display: inline-block;font-family:'Source Sans Pro', sans-serif;letter-spacing:3px;">
							A1 QUALITY NATURAL SPIRULINA PRODUCING COMPANY
						</div>

						<div class="tp-caption tp-shape tp-shapewrapper " id="slide-3204-layer-2" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="normal" data-type="shape" data-basealign="slide" data-responsive_offset="off" data-responsive="off" data-frames='[{"delay":10,"speed":2000,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]' data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 1;background-color:rgba(0,0,0,0.70);"> </div>

						<!-- LAYER NR. 3 -->
						<div class="tp-caption  " id="slide-3204-layer-3" data-x="['left','left','left','left']" data-hoffset="['364','114','76','26']" data-y="['top','top','top','top']" data-voffset="['302','352','235','225']" data-width="['100%','100%','100%','100%']" data-fontsize="['40','40','40','40']" data-lineheight="['82','82','60','60']" data-height="none" data-whitespace="normal" data-type="text" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":650,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; font-size: 75px; line-height: 81px; font-weight: 300; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;">
							To complete your nutritional needs
						</div>

						<!-- LAYER NR. 4 -->
						<div class="tp-caption  " id="slide-3204-layer-4" data-x="['left','left','left','left']" data-hoffset="['364','118','76','26']" data-y="['top','top','top','top']" data-voffset="['382','272','305','295']" data-width="['100%','100%','100%','100%']" data-fontsize="['82','82','60','60']" data-lineheight="['82','82','60','60']" data-height="none" data-whitespace="normal" data-type="text" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":650,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; font-size: 82px; line-height: 82px; font-weight: 700; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;">
							Leading Exporter
						</div>

						<!-- LAYER NR. 5 -->
						<!-- <a class="tp-caption rev-btn clv_btn" href="javascript:;" id="slide-3204-layer-5" data-x="['left','left','left','left']" data-hoffset="['364','114','76','26']" data-y="['top','top','top','top']" data-voffset="['489','550','385','376']" data-fontweight="['500','500','500','500']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="button" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":800,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[45,45,45,45]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[45,45,45,45]" style="z-index: 8; white-space: nowrap;">read more</a> -->

						<!-- LAYER NR. 2 -->

					</li>
					<!-- SLIDE  -->
					<li data-index="rs-3205" data-transition="slideoververtical" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="../../assets/images/news2-1-100x50.jpg" data-rotate="0" data-saveperformance="off" data-title="" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
						<!-- MAIN IMAGE -->
						<img src="images/product_1.jpg" alt="image" data-lazyload="" data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
						<!-- LAYERS -->

						<!-- LAYER NR. 5 -->
						<div class="tp-caption  " id="slide-3205-layer-1" data-x="['left','left','left','left']" data-hoffset="['364','114','76','26']" data-y="['top','top','top','top']" data-voffset="['262','252','195','185']" data-fontsize="['20','20','20','20']" data-lineheight="['22','22','22','22']" data-width="['700','700','700','700']" data-height="none" data-whitespace="normal" data-type="text" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 5; white-space: nowrap; font-size: 20px; font-weight: 700; color: #1fa12e; display: inline-block;font-family:'Source Sans Pro', sans-serif;letter-spacing:3px;">
							A1 QUALITY NATURAL SPIRULINA PRODUCING COMPANY </div>

						<!-- LAYER NR. 6 -->
						<div class="tp-caption tp-shape tp-shapewrapper " id="slide-3205-layer-2" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="normal" data-type="shape" data-basealign="slide" data-responsive_offset="off" data-responsive="off" data-frames='[{"delay":10,"speed":2000,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]' data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 1;background-color:rgba(0,0,0,0.70);"> </div>

						<!-- LAYER NR. 7 -->
						<div class="tp-caption  " id="slide-3205-layer-3" data-x="['left','left','left','left']" data-hoffset="['364','114','76','26']" data-y="['top','top','top','top']" data-voffset="['302','352','235','225']" data-width="['100%','100%','100%','100%']" data-width="['100%','100%','100%','100%']" data-fontsize="['40','40','60','60']" data-height="none" data-whitespace="normal" data-type="text" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":650,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; font-size: 40px; line-height: 81px; font-weight: 300; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;">
							To complete your nutritional needs </div>

						<!-- LAYER NR. 8 -->
						<div class="tp-caption  " id="slide-3205-layer-4" data-x="['left','left','left','left']" data-hoffset="['364','114','76','26']" data-y="['top','top','top','top']" data-voffset="['382','272','305','295']" data-width="['100%','100%','100%','100%']" data-fontsize="['82','82','60','60']" data-lineheight="['82','82','60','60']" data-height="none" data-whitespace="normal" data-type="text" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":650,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; font-size: 82px; line-height: 82px; font-weight: 700; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;">
							Leading Exporter</div>
						<!-- LAYER NR. 9 -->
						<!-- <a class="tp-caption rev-btn clv_btn" href="javascript:;" id="slide-3205-layer-5" data-x="['left','left','left','left']" data-hoffset="['364','114','76','26']" data-y="['top','top','top','top']" data-voffset="['489','550','385','376']" data-fontweight="['500','500','500','500']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="button" data-basealign="slide" data-responsive_offset="on" data-responsive="off" data-frames='[{"from":"y:50px;opacity:0;","speed":1500,"to":"o:1;","delay":800,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[45,45,45,45]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[45,45,45,45]" style="z-index: 8; white-space: nowrap;">read more</a> -->
					</li>

				</ul>
				<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
			</div>
		</div><!-- END REVOLUTION SLIDER -->
	</div>
	<!--Revolution Silder-->
	<div class="org_service_wrapper clv_section" id="products">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4">
					<div class="org_left_service">
						<div class="service_description">
							<h3>awesome spirulina products</h3>
							<img src="images/org_underline.png" alt="image">
							<p>
								Here are few of our amazing natural spirulina products to meet all your desired nutritional needs!
								Why wait? Contact us to know more!
							</p>

						</div>
						<div class="service_contact">
							<span>
								<!--?xml version="1.0" encoding="iso-8859-1"?-->
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 480.56 480.56" style="enable-background:new 0 0 480.56 480.56;" xml:space="preserve" width="32px" height="32px">
									<g>
										<g>
											<path style="fill:#27ae93;" d="M365.354,317.9c-15.7-15.5-35.3-15.5-50.9,0c-11.9,11.8-23.8,23.6-35.5,35.6c-3.2,3.3-5.9,4-9.8,1.8
											c-7.7-4.2-15.9-7.6-23.3-12.2c-34.5-21.7-63.4-49.6-89-81c-12.7-15.6-24-32.3-31.9-51.1c-1.6-3.8-1.3-6.3,1.8-9.4
											c11.9-11.5,23.5-23.3,35.2-35.1c16.3-16.4,16.3-35.6-0.1-52.1c-9.3-9.4-18.6-18.6-27.9-28c-9.6-9.6-19.1-19.3-28.8-28.8
											c-15.7-15.3-35.3-15.3-50.9,0.1c-12,11.8-23.5,23.9-35.7,35.5c-11.3,10.7-17,23.8-18.2,39.1c-1.9,24.9,4.2,48.4,12.8,71.3
											c17.6,47.4,44.4,89.5,76.9,128.1c43.9,52.2,96.3,93.5,157.6,123.3c27.6,13.4,56.2,23.7,87.3,25.4c21.4,1.2,40-4.2,54.9-20.9
											c10.2-11.4,21.7-21.8,32.5-32.7c16-16.2,16.1-35.8,0.2-51.8C403.554,355.9,384.454,336.9,365.354,317.9z"></path>
											<path style="fill:#27ae93;" d="M346.254,238.2l36.9-6.3c-5.8-33.9-21.8-64.6-46.1-89c-25.7-25.7-58.2-41.9-94-46.9l-5.2,37.1
											c27.7,3.9,52.9,16.4,72.8,36.3C329.454,188.2,341.754,212,346.254,238.2z"></path>
											<path style="fill:#27ae93;" d="M403.954,77.8c-42.6-42.6-96.5-69.5-156-77.8l-5.2,37.1c51.4,7.2,98,30.5,134.8,67.2c34.9,34.9,57.8,79,66.1,127.5
											l36.9-6.3C470.854,169.3,444.354,118.3,403.954,77.8z"></path>
										</g>
									</g>
								</svg>
							</span>
							<h4>02453-221531</h4>
						</div>
					</div>
				</div>
				<div class="col-lg-8 col-md-8">
					<div class="org_right_service">
						<div class="row">
							<div class="col-md-4">
								<div class="service_block">
									<img src="images/product_1.jpg" alt="image">
									<h3>Powder</h3>
									<p>Adira's Natural Spirulina Powder</p>
								</div>
							</div>
							<div class="col-md-4">
								<div class="service_block">
									<img src="images/product_2.jpg" alt="image">
									<h3>Tablets</h3>
									<p>Adira's Natural Spirulina Tablets 500 Mg</p>
								</div>
							</div>
							<div class="col-md-4">
								<div class="service_block">
									<img src="images/product_3.jpg" alt="image">
									<h3>Capsules</h3>
									<p>Adira's Natural Spirulina Capsules 500 Mg</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="product_detail_wrapper" id="about">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 text-center main-heading">
					<h1 class="">About Spirulina</h1>
					<img src="images/org_underline2.png" alt="image">
				</div>
				<div class="col-lg-12 col-md-12">
					<div class="clv_about_agriculture_wrapper">
						<div class="container">
							<div class="row">
								<div class="col-md-6 col-lg-6">
									<div class="about_agri_image">
										<img src="images/image_2.webp" alt="image" />
									</div>
								</div>
								<div class="col-md-6 col-lg-6">
									<div class="about_agri_content">
										<h2>What is Spirulina?</h2>
										<h6>Let your food be your medicine - Hippocrates</h6>
										<p>Spirulina is algae grown in salinated water.
											It is rich in proteins (60-70 %), minerals, iron, calcium, vitamins.
											It has all essential amino acid & fatty acids. It has GLA (Gammalinolenic Acid) which is very useful fatty acid for body.
											It is potent anti-inflammatory food, it has antiallergy properpes, it boost immunity, promote growh, metabolism, decreases cholestrol & also helps to loose weight prevent hairfall.
											Also, it has excellent antioxidant activity than any food or drug.
										</p>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 text-center main-heading">
					<h1>Spirulina - Benefits and Uses</h1>
					<img src="images/org_underline2.png" alt="image">
				</div>
				<div class="col-lg-12 col-md-12">
					<div class="product_detail_tab">
						<ul class="nav nav-tabs">
							<li><a data-toggle="tab" class="active" href="#english">English</a></li>
							<li><a data-toggle="tab" href="#hindi">Hindi</a></li>
							<li><a data-toggle="tab" href="#marathi">Marathi</a></li>
						</ul>
						<div class="tab-content">
							<div id="english" class="tab-pane fade show active">
								<p>
									Eating of spirulina is extremely beneficial as the food we eat nowadays does not provide all
									the nutrients that our body needs. It is rich in proteins 60 to 75%, minerals, vitamins, antioxidants and iron, so NASA & WHO has called it as Super Food. As it is rich in nutrients and easy to carry, astronauts complete their missions by eating spirulina.
									Spirulina is potent anti-inflammatory, potent antioxidant, potent antiallergic. Here are few more benefits and uses of Spirulina:
								</p>
								<ol>
									<li>Always getting sick, repeated infections, & weak immunity, it boosts immunity.</li>
									<li>General Weakness, feeling lack of energy, limb pain.</li>
									<li>Persistent Allergic Col.</li>
									<li>Anemi.</li>
									<li>To reduce body fat & cholestero.</li>
									<li>prevent cancer, as it is extremely rich in antioxidant.</li>
									<li>To reduce various types of inflammations in the body.</li>
									<li>Prevent hypertension & Diabete.</li>
									<li>To lose weight, increases metabolism and maintain healthy appetit.</li>
									<li> Removes toxins and harmful substances from the body and protects the live.</li>
									<li> Increases memory.</li>
									<li> Improves vision.</li>
									<li> Stops the growth of HIV.</li>
									<li> Reduces the risk of paralysis and seizures.</li>
									<li> Reduces stress and prevents depression.</li>
									<li> Antiaging, maintain skin glow& texture.</li>
									<li> To get calcium, vitamin K, E as well as abundant protein.</li>
									<li> Prevent growth retardation in young children & prevent malnutrituion.</li>
									<li> Disorders of digestive system, relieves constipation & Gases trouble.</li>
									<li> Prevent Hairfall.</li>
								</ol>

							</div>
							<div id="hindi" class="tab-pane fade">
								<h3 class="text-center">स्पिरुलिना के उपयोग एंवम लाभ <br></h3>
								<ul>

									स्पिरुलिना खाना बेहद फायदेमंद है क्योंकी आजकाल हम जो खान खाते हैं वह हमारे शरीर को सभी
									पोषक तत्व प्रदान नहीं करता| नासा और जागतिक अरोग्य संघटन ने इसे सुपर फुट करार दिया है क्योंकी यह पोषक तत्वें से
									भरपूर है और अंतरिक्ष यात्री स्पिरुलिना खाकर अपने मिशन को अंजाम देते हैं|<br><br>
									<li>१) हमेशा बीमार रहना. बारबार, जंतुसंक्रम, इन्फेक्शन व रोग प्रतिकिरक क्षमता कि कमी| यह इम्युनिटी बढता है </li>
									<li>२) कमजोरी, गलावट, थकान, हमेशा बदनदर्द, हाथपांव दुःखाना </li>
									<li>३) लगातार एलर्जी जुकाम </li>
									<li>४) खुन की कमी अनेमिया </li>
									<li>५) शरीर की चर्बी को कम करने के लिए तथा कोलेस्टेरॉल घटाने के लिए </li>
									<li>६) कैन्सर कर्क रोग न हो इस हेतू यह ऑन्टी औंक्सिडेन्ट से भरपूर .है </li>
									<li>७) शरीर में विभिन्न प्रकार कि सुजन को कम करने के लिए|</li>
									<li>८) बीपी और शुगर नाहीं बढाना चाहिए|</li>
									<li>९) वजन कम करने के लिए| यह मेटाबालिझम बढाता है|</li>
									<li>१०) शरीर से विषारी पदार्थो और हानिकारक पदार्थो को निकालता है और लिव्हर की रक्षा करता है|</li>
									<li>११। याददाश बढाता है|</li>
									<li>१२। द्रुष्टी में सुधार </li>
									<li>१३) एचआईवी के मिरगी के दौर रोकता है|</li>
									<li>१४) पक्षाघात और दौर की संभावना कम करता है|</li>
									<li>१५) तणाव कम करता है और अवसाद को रोकता है </li>
									<li>१६) उम्र नहीं देखनी चाहिए स्किन ग्लोईंग रखता है </li>
									<li>१७) कैल्शियम, विटामिन के, ई के साथ-साथ भरपूर मात्रा में प्रोटीन प्राप्त करने के लिए </li>
									<li>१८) छोटे बच्चे के विकास वृध्दी में रुकावट न आए </li>
									<li>१९) बाल झडना रोकने के लिए </li>
									<li>२०) पाचन संस्था की समस्थाए, गॅस एवं कब्ज</li>
								</ul>
							</div>
							<div id="marathi" class="tab-pane fade">
								<h3 class="devagiri-font text-center"><b>paoYak GaTkaMnaI samaRQd Asao spI$ilanaa ka #aavao:</b> </h3><br><br>
								<ol  class="devagiri-font">

									paoYak GaTkaMnaI samaRQd Asao spI$ilanaa ka #aavao:
									Aajakala AapNa jao Anna #aatao to Aaplyaa SarIrasa AavaSyak sava- paoYakGaTk dot naahI %yaamaULo spI$laInaa #aaNao A%yaMt fayadoSaIr Aaho. paoYakGaTkMaNaI samaRQd\ AsalyaamaULo naasaanao yaalaa saupr fuT saMbaaoQalao Aaho va AMatraLvaIr ho spI$laInaa #aavaunaca AaplaI maaohImaa par paDtat.<br><br>

									<li>naohmaI AajaarI pDNao Jnafo@Sana jaMtUsaMsaga- haoNao raogap`itkark Sa@tI kmaI AsaNao.</li>
									<li>ASa@tpNaa kmajaaorI hatpaya AMgaduKI gaLuna jaaNao </li>
									<li>,satt haoNaarI AlajaI-caI sadI- saayanasacaa Haasa </li>
									<li> r@t kmaI AsaNao haoNao </li>
									<li> SarIratIla carbaI kaolaosTala kmaI krNyaasaazI </li>
									<li> k^nsar haovaUnayaomhNauna </li>
									<li> SarIratIla ivaivaQa p`karcaI sauja kmaI krNyaasaazI </li>
									<li> baIpI va saugar saa#ar vaaZu nayao mhNauna </li>
									<li> vajana kmaI krNyaasaazI</li>
									<li> ivaYaarI va hanaIkark t%va GaTk SairratUuna kaZuna Takto va ilavhrcao rxaNa krto </li>
									<li> smarNaSa@tI vaaZvato </li>
									<li> dRYTI sauQaarto</li>
									<li> ecaAayavhIcaI vaaZ qaaMbavato</li>
									<li>p^ralaosaIsa va A^Tkcaa Qaaoka kmaI krto </li>
									<li> taNatNaava kmaI krto va iDp` oSana p`itbaMQak</li>
									<li> vaya idsau nayao vaarQa@ya yaovau nayao mhNauna A@TI yaojaIga</li>
									<li> k^lasaIyama ivaTamaIna ko, [- tsaoca maubalak p`aoTIna iMmaLvaNyaasaazI</li>
									<li>lahana maulaaMmaQyao vaaZ KuMTu nayao mhNauna</li>
</ol>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--Team-->
	<div class="agri_blog_wrapper clv_section" id="team">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-6 col-md-6">
					<div class="clv_heading">
						<h3>About Us</h3>
						<!-- <div class="clv_underline"><img src="images/agri_underline2.png" alt="image" /></div> -->
					</div>
				</div>
			</div>
			<div class="agri_blog_inner">
				<div class="row">
					<div class="col-lg-6 col-md-6">
						<div class="blog_section">
							<div class="agri_blog_image">
								<img src="./images/hospital_building.jpg" alt="image" />
								<span class="agri_blog_date">INSTITUTION</span>
								


							</div>
							
							<div class="agri_blog_content">
								<h3><a>GODAVARI HOSPITAL</a></h3>
								<hr/>
								<div class="blog_user">
									<div class="user_name">
										<img src="./images/phone_icon.png" alt="image" />
										<a href="javascript:;"><span>8669621561</span></a>
									</div>
									<div class="user_name">
									<img src="./images/marker_icon.png" alt="image" />
										<a href="https://maps.app.goo.gl/XZRw8maqBNCk4FCo6" target="_blank"><span>Click Here</span></a>
									</div>
								</div>
								<p> GODAVARI HOSPITAL, Near Kamal Chitra Mandir,
ICICI Bank, Yogeshwar Colony, Gangakhed (EST 2005)</p><br/>
<h6><b>SERVICES:</b></h6>
<ol> 	
<li>NATURAL & SAFE BIRTH/LABOUR</li>
<li>CAESARIAN SECTION (LSCS) FOR GENUINE INDICATION</li>
<li>LEGAL ABORTION UPTO 12 WEEKS</li>
<li>HYSTRECTOMIES ABDOMINAL & VAGINAL ,NONDESCEND VAGINAL</li>
<li>CERVICA ENCIRLCLAGE</li>
<li>TUBECTOMY</li>
  <li> CONTRACEPTIONS</li>

</ol>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6">
						<div class="right_blog_section">
						<div class="right_blog_block">
								<div class="right_blog_image">
								<img src="<?php echo base_url(); ?>images/nagargoje_sir.jpg">

								</div>
								<div class="right_blog_content">
									<span class="agri_blog_date">MBBS DGO</span>
									<h3><a>Dr.Dilip Nagargoje</a></h3>
									<p>Consultant Gynaecologist & obstetrician </p>
								</div>
							</div>
							<div class="right_blog_block">
								<div class="right_blog_image">
								<img src="<?php echo base_url(); ?>images/nagargoje_madam.jpg">


								</div>
								<div class="right_blog_content">
									<span class="agri_blog_date">BHMS</span>
									<h3><a>Dr Archana Dilip Nagargoje</a></h3>
									<p>Vice-Chairman,
											Dakshraj Ng Biomass Pvt Ltd </p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>

	</div>