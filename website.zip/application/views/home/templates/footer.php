<section class = "footer" id="footer">
    <div class = "overlay">
        <div class = "container">
            <h3 class = "text-center"><b>DAKSHRAJ NG BIOMASS PVT LTD</b></h3><br>
            <div class = "row">
                <div class = "col-md-1"></div>
                <div class = "col-md-3">
                    <img src = "<?php echo base_url();?>images/qr-code.png" width="100%">
                </div>
                <div class = "col-12 col-md-7">
                    <h6><i class = "fa fa-map-marker"></i>&nbsp;
                    Spirulina Manufacturing Plant: Survey No 394/1, Suralwadi, Near Yadnya Bhoomi, Gangakhed(Ta), Parbhani(Dist)
                </h6>

                    <h6><i class="fa fa-phone" aria-hidden="true"></i>
                        &nbsp;02453-221531</h6>
                    <h6><i class="fa fa-envelope" aria-hidden="true"></i>
                        &nbsp;dakshraj@gmail.com</h6>
                    <h6><i class="fa fa-globe" aria-hidden="true"></i>
                        &nbsp;https://dakshraj.com/</h6>
                </div>
            </div>
            <hr>
            <div class = "row">
              <div class = "col-md-12">
                <p>&copy; Copyright &copy; DAKSHRAJ NG BIOMASS PVT LTD. All Rights Reserved</p>  
              </div>
            </div>
        </div>
    </div>
    <script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/jquery.themepunch.tools.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.countTo.js"></script>
<script src="js/isotope.min.js"></script>
<script src="js/nice-select.min.js"></script>
<script src="js/range.js"></script>
<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->	
<script src="js/revolution.extension.actions.min.js"></script>
<script src="js/revolution.extension.kenburn.min.js"></script>
<script src="js/revolution.extension.layeranimation.min.js"></script>
<script src="js/revolution.extension.migration.min.js"></script>
<script src="js/revolution.extension.parallax.min.js"></script>
<script src="js/revolution.extension.slideanims.min.js"></script>
<script src="js/revolution.extension.video.min.js"></script>
<script src="js/custom.js"></script>
</section>
</div>