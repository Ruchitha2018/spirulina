<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['consultancy'] = 'home/consultancy';
$route['contact-us'] = 'home/contact_us';
$route['Twin-Screw-And-Barrel'] = 'home/twin_screw_And_barrel';
$route['Die-Head-And-Dies'] = 'home/die_head_and_dies';
